﻿using AlphaShop.Data;

namespace AlphaShop.Models
{
    public class ProductModel
    {
        public Product? product { get; set; }
        public int option_type { get; set; }
        public int option_size { get; set; }

    }
}
