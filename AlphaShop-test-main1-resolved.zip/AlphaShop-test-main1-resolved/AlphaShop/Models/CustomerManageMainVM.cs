﻿namespace AlphaShop.Models
{
    public class CustomerManageMainVM
    {

    }
}
